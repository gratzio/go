// Structs and functions used in stress tests
package stress
