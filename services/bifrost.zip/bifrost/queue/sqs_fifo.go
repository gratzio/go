package queue

func (s *SQSFiFo) Add(tx Transaction) error {
	panic("Not implemented yet")
	return nil
}

func (s *SQSFiFo) Pool() (*Transaction, error) {
	panic("Not implemented yet")
	return nil, nil
}
